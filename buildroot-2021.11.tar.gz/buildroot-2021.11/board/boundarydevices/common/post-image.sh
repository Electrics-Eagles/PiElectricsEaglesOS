#!/bin/sh

support/scripts/genimage.sh -c $(dirname $0)/genimage.cfg

exit $?
