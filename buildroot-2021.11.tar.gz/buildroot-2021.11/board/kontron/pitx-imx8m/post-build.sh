#!/bin/sh

mkdir -p $TARGET_DIR/boot/
cp $BINARIES_DIR/boot.scr $TARGET_DIR/boot/boot.scr
